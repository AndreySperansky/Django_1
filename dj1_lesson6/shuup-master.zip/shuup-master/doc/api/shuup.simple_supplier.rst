shuup.simple\_supplier package
==============================

Subpackages
-----------

.. toctree::

    shuup.simple_supplier.admin_module

Submodules
----------

shuup.simple\_supplier.forms module
-----------------------------------

.. automodule:: shuup.simple_supplier.forms
    :members:
    :undoc-members:
    :show-inheritance:

shuup.simple\_supplier.models module
------------------------------------

.. automodule:: shuup.simple_supplier.models
    :members:
    :undoc-members:
    :show-inheritance:

shuup.simple\_supplier.module module
------------------------------------

.. automodule:: shuup.simple_supplier.module
    :members:
    :undoc-members:
    :show-inheritance:

shuup.simple\_supplier.notify\_events module
--------------------------------------------

.. automodule:: shuup.simple_supplier.notify_events
    :members:
    :undoc-members:
    :show-inheritance:

shuup.simple\_supplier.notify\_script\_template module
------------------------------------------------------

.. automodule:: shuup.simple_supplier.notify_script_template
    :members:
    :undoc-members:
    :show-inheritance:

shuup.simple\_supplier.utils module
-----------------------------------

.. automodule:: shuup.simple_supplier.utils
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.simple_supplier
    :members:
    :undoc-members:
    :show-inheritance:
