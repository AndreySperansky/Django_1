shuup.admin.modules.shops package
=================================

Subpackages
-----------

.. toctree::

    shuup.admin.modules.shops.views

Submodules
----------

shuup.admin.modules.shops.forms module
--------------------------------------

.. automodule:: shuup.admin.modules.shops.forms
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.admin.modules.shops
    :members:
    :undoc-members:
    :show-inheritance:
