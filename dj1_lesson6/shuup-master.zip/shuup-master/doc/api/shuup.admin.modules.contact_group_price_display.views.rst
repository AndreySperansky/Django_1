shuup.admin.modules.contact\_group\_price\_display.views package
================================================================

Submodules
----------

shuup.admin.modules.contact\_group\_price\_display.views.edit module
--------------------------------------------------------------------

.. automodule:: shuup.admin.modules.contact_group_price_display.views.edit
    :members:
    :undoc-members:
    :show-inheritance:

shuup.admin.modules.contact\_group\_price\_display.views.forms module
---------------------------------------------------------------------

.. automodule:: shuup.admin.modules.contact_group_price_display.views.forms
    :members:
    :undoc-members:
    :show-inheritance:

shuup.admin.modules.contact\_group\_price\_display.views.list module
--------------------------------------------------------------------

.. automodule:: shuup.admin.modules.contact_group_price_display.views.list
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.admin.modules.contact_group_price_display.views
    :members:
    :undoc-members:
    :show-inheritance:
