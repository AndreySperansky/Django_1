shuup.tasks.admin\_module.views package
=======================================

Submodules
----------

shuup.tasks.admin\_module.views.edit module
-------------------------------------------

.. automodule:: shuup.tasks.admin_module.views.edit
    :members:
    :undoc-members:
    :show-inheritance:

shuup.tasks.admin\_module.views.list module
-------------------------------------------

.. automodule:: shuup.tasks.admin_module.views.list
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.tasks.admin_module.views
    :members:
    :undoc-members:
    :show-inheritance:
