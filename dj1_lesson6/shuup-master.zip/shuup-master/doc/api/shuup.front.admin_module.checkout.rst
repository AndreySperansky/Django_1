shuup.front.admin\_module.checkout package
==========================================

Submodules
----------

shuup.front.admin\_module.checkout.form\_parts module
-----------------------------------------------------

.. automodule:: shuup.front.admin_module.checkout.form_parts
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.front.admin_module.checkout
    :members:
    :undoc-members:
    :show-inheritance:
