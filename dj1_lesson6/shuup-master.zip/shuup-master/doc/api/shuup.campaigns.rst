shuup.campaigns package
=======================

Subpackages
-----------

.. toctree::

    shuup.campaigns.admin_module
    shuup.campaigns.api
    shuup.campaigns.management
    shuup.campaigns.models
    shuup.campaigns.templates
    shuup.campaigns.utils

Submodules
----------

shuup.campaigns.apps module
---------------------------

.. automodule:: shuup.campaigns.apps
    :members:
    :undoc-members:
    :show-inheritance:

shuup.campaigns.consts module
-----------------------------

.. automodule:: shuup.campaigns.consts
    :members:
    :undoc-members:
    :show-inheritance:

shuup.campaigns.exceptions module
---------------------------------

.. automodule:: shuup.campaigns.exceptions
    :members:
    :undoc-members:
    :show-inheritance:

shuup.campaigns.modules module
------------------------------

.. automodule:: shuup.campaigns.modules
    :members:
    :undoc-members:
    :show-inheritance:

shuup.campaigns.reports module
------------------------------

.. automodule:: shuup.campaigns.reports
    :members:
    :undoc-members:
    :show-inheritance:

shuup.campaigns.signal\_handlers module
---------------------------------------

.. automodule:: shuup.campaigns.signal_handlers
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.campaigns
    :members:
    :undoc-members:
    :show-inheritance:
