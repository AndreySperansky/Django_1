shuup.admin.modules.services package
====================================

Subpackages
-----------

.. toctree::

    shuup.admin.modules.services.views
    shuup.admin.modules.services.weight_based_pricing

Submodules
----------

shuup.admin.modules.services.base\_form\_part module
----------------------------------------------------

.. automodule:: shuup.admin.modules.services.base_form_part
    :members:
    :undoc-members:
    :show-inheritance:

shuup.admin.modules.services.behavior\_form\_part module
--------------------------------------------------------

.. automodule:: shuup.admin.modules.services.behavior_form_part
    :members:
    :undoc-members:
    :show-inheritance:

shuup.admin.modules.services.forms module
-----------------------------------------

.. automodule:: shuup.admin.modules.services.forms
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.admin.modules.services
    :members:
    :undoc-members:
    :show-inheritance:
