shuup.testing.supplier\_pricing package
=======================================

Submodules
----------

shuup.testing.supplier\_pricing.pricing module
----------------------------------------------

.. automodule:: shuup.testing.supplier_pricing.pricing
    :members:
    :undoc-members:
    :show-inheritance:

shuup.testing.supplier\_pricing.supplier\_strategy module
---------------------------------------------------------

.. automodule:: shuup.testing.supplier_pricing.supplier_strategy
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.testing.supplier_pricing
    :members:
    :undoc-members:
    :show-inheritance:
