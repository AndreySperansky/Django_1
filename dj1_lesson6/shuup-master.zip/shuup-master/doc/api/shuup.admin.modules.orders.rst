shuup.admin.modules.orders package
==================================

Subpackages
-----------

.. toctree::

    shuup.admin.modules.orders.views

Submodules
----------

shuup.admin.modules.orders.json\_order\_creator module
------------------------------------------------------

.. automodule:: shuup.admin.modules.orders.json_order_creator
    :members:
    :undoc-members:
    :show-inheritance:

shuup.admin.modules.orders.mass\_actions module
-----------------------------------------------

.. automodule:: shuup.admin.modules.orders.mass_actions
    :members:
    :undoc-members:
    :show-inheritance:

shuup.admin.modules.orders.receivers module
-------------------------------------------

.. automodule:: shuup.admin.modules.orders.receivers
    :members:
    :undoc-members:
    :show-inheritance:

shuup.admin.modules.orders.sections module
------------------------------------------

.. automodule:: shuup.admin.modules.orders.sections
    :members:
    :undoc-members:
    :show-inheritance:

shuup.admin.modules.orders.toolbar module
-----------------------------------------

.. automodule:: shuup.admin.modules.orders.toolbar
    :members:
    :undoc-members:
    :show-inheritance:

shuup.admin.modules.orders.utils module
---------------------------------------

.. automodule:: shuup.admin.modules.orders.utils
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.admin.modules.orders
    :members:
    :undoc-members:
    :show-inheritance:
