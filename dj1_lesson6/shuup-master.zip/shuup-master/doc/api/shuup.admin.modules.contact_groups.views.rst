shuup.admin.modules.contact\_groups.views package
=================================================

Submodules
----------

shuup.admin.modules.contact\_groups.views.delete module
-------------------------------------------------------

.. automodule:: shuup.admin.modules.contact_groups.views.delete
    :members:
    :undoc-members:
    :show-inheritance:

shuup.admin.modules.contact\_groups.views.edit module
-----------------------------------------------------

.. automodule:: shuup.admin.modules.contact_groups.views.edit
    :members:
    :undoc-members:
    :show-inheritance:

shuup.admin.modules.contact\_groups.views.forms module
------------------------------------------------------

.. automodule:: shuup.admin.modules.contact_groups.views.forms
    :members:
    :undoc-members:
    :show-inheritance:

shuup.admin.modules.contact\_groups.views.list module
-----------------------------------------------------

.. automodule:: shuup.admin.modules.contact_groups.views.list
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.admin.modules.contact_groups.views
    :members:
    :undoc-members:
    :show-inheritance:
