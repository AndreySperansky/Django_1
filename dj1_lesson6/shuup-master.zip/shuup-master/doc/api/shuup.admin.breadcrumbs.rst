shuup.admin.breadcrumbs package
===============================

Module contents
---------------

.. automodule:: shuup.admin.breadcrumbs
    :members:
    :undoc-members:
    :show-inheritance:
