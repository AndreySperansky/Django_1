shuup.admin.modules.categories.views package
============================================

Submodules
----------

shuup.admin.modules.categories.views.copy module
------------------------------------------------

.. automodule:: shuup.admin.modules.categories.views.copy
    :members:
    :undoc-members:
    :show-inheritance:

shuup.admin.modules.categories.views.delete module
--------------------------------------------------

.. automodule:: shuup.admin.modules.categories.views.delete
    :members:
    :undoc-members:
    :show-inheritance:

shuup.admin.modules.categories.views.edit module
------------------------------------------------

.. automodule:: shuup.admin.modules.categories.views.edit
    :members:
    :undoc-members:
    :show-inheritance:

shuup.admin.modules.categories.views.list module
------------------------------------------------

.. automodule:: shuup.admin.modules.categories.views.list
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.admin.modules.categories.views
    :members:
    :undoc-members:
    :show-inheritance:
