shuup.admin package
===================

Subpackages
-----------

.. toctree::

    shuup.admin.breadcrumbs
    shuup.admin.dashboard
    shuup.admin.forms
    shuup.admin.modules
    shuup.admin.template_helpers
    shuup.admin.templatetags
    shuup.admin.utils
    shuup.admin.views

Submodules
----------

shuup.admin.base module
-----------------------

.. automodule:: shuup.admin.base
    :members:
    :undoc-members:
    :show-inheritance:

shuup.admin.browser\_config module
----------------------------------

.. automodule:: shuup.admin.browser_config
    :members:
    :undoc-members:
    :show-inheritance:

shuup.admin.currencybound module
--------------------------------

.. automodule:: shuup.admin.currencybound
    :members:
    :undoc-members:
    :show-inheritance:

shuup.admin.error\_handlers module
----------------------------------

.. automodule:: shuup.admin.error_handlers
    :members:
    :undoc-members:
    :show-inheritance:

shuup.admin.form\_modifier module
---------------------------------

.. automodule:: shuup.admin.form_modifier
    :members:
    :undoc-members:
    :show-inheritance:

shuup.admin.form\_part module
-----------------------------

.. automodule:: shuup.admin.form_part
    :members:
    :undoc-members:
    :show-inheritance:

shuup.admin.menu module
-----------------------

.. automodule:: shuup.admin.menu
    :members:
    :undoc-members:
    :show-inheritance:

shuup.admin.middleware module
-----------------------------

.. automodule:: shuup.admin.middleware
    :members:
    :undoc-members:
    :show-inheritance:

shuup.admin.module\_registry module
-----------------------------------

.. automodule:: shuup.admin.module_registry
    :members:
    :undoc-members:
    :show-inheritance:

shuup.admin.settings module
---------------------------

.. automodule:: shuup.admin.settings
    :members:
    :undoc-members:
    :show-inheritance:

shuup.admin.shop\_provider module
---------------------------------

.. automodule:: shuup.admin.shop_provider
    :members:
    :undoc-members:
    :show-inheritance:

shuup.admin.signals module
--------------------------

.. automodule:: shuup.admin.signals
    :members:
    :undoc-members:
    :show-inheritance:

shuup.admin.supplier\_provider module
-------------------------------------

.. automodule:: shuup.admin.supplier_provider
    :members:
    :undoc-members:
    :show-inheritance:

shuup.admin.toolbar module
--------------------------

.. automodule:: shuup.admin.toolbar
    :members:
    :undoc-members:
    :show-inheritance:

shuup.admin.urls module
-----------------------

.. automodule:: shuup.admin.urls
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.admin
    :members:
    :undoc-members:
    :show-inheritance:
