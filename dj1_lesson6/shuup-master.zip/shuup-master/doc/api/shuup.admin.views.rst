shuup.admin.views package
=========================

Submodules
----------

shuup.admin.views.dashboard module
----------------------------------

.. automodule:: shuup.admin.views.dashboard
    :members:
    :undoc-members:
    :show-inheritance:

shuup.admin.views.edit module
-----------------------------

.. automodule:: shuup.admin.views.edit
    :members:
    :undoc-members:
    :show-inheritance:

shuup.admin.views.home module
-----------------------------

.. automodule:: shuup.admin.views.home
    :members:
    :undoc-members:
    :show-inheritance:

shuup.admin.views.menu module
-----------------------------

.. automodule:: shuup.admin.views.menu
    :members:
    :undoc-members:
    :show-inheritance:

shuup.admin.views.password module
---------------------------------

.. automodule:: shuup.admin.views.password
    :members:
    :undoc-members:
    :show-inheritance:

shuup.admin.views.search module
-------------------------------

.. automodule:: shuup.admin.views.search
    :members:
    :undoc-members:
    :show-inheritance:

shuup.admin.views.select module
-------------------------------

.. automodule:: shuup.admin.views.select
    :members:
    :undoc-members:
    :show-inheritance:

shuup.admin.views.tour module
-----------------------------

.. automodule:: shuup.admin.views.tour
    :members:
    :undoc-members:
    :show-inheritance:

shuup.admin.views.wizard module
-------------------------------

.. automodule:: shuup.admin.views.wizard
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.admin.views
    :members:
    :undoc-members:
    :show-inheritance:
