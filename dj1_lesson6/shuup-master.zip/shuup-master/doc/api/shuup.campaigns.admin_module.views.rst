shuup.campaigns.admin\_module.views package
===========================================

Module contents
---------------

.. automodule:: shuup.campaigns.admin_module.views
    :members:
    :undoc-members:
    :show-inheritance:
