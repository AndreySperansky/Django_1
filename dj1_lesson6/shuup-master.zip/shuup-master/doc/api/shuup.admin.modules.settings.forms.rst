shuup.admin.modules.settings.forms package
==========================================

Submodules
----------

shuup.admin.modules.settings.forms.columns module
-------------------------------------------------

.. automodule:: shuup.admin.modules.settings.forms.columns
    :members:
    :undoc-members:
    :show-inheritance:

shuup.admin.modules.settings.forms.system module
------------------------------------------------

.. automodule:: shuup.admin.modules.settings.forms.system
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.admin.modules.settings.forms
    :members:
    :undoc-members:
    :show-inheritance:
