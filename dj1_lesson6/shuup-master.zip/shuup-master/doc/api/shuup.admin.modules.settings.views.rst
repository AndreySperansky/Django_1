shuup.admin.modules.settings.views package
==========================================

Submodules
----------

shuup.admin.modules.settings.views.list module
----------------------------------------------

.. automodule:: shuup.admin.modules.settings.views.list
    :members:
    :undoc-members:
    :show-inheritance:

shuup.admin.modules.settings.views.system module
------------------------------------------------

.. automodule:: shuup.admin.modules.settings.views.system
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.admin.modules.settings.views
    :members:
    :undoc-members:
    :show-inheritance:
