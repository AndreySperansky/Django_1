shuup.admin.modules.contacts.views package
==========================================

Submodules
----------

shuup.admin.modules.contacts.views.detail module
------------------------------------------------

.. automodule:: shuup.admin.modules.contacts.views.detail
    :members:
    :undoc-members:
    :show-inheritance:

shuup.admin.modules.contacts.views.edit module
----------------------------------------------

.. automodule:: shuup.admin.modules.contacts.views.edit
    :members:
    :undoc-members:
    :show-inheritance:

shuup.admin.modules.contacts.views.list module
----------------------------------------------

.. automodule:: shuup.admin.modules.contacts.views.list
    :members:
    :undoc-members:
    :show-inheritance:

shuup.admin.modules.contacts.views.mass\_edit module
----------------------------------------------------

.. automodule:: shuup.admin.modules.contacts.views.mass_edit
    :members:
    :undoc-members:
    :show-inheritance:

shuup.admin.modules.contacts.views.reset module
-----------------------------------------------

.. automodule:: shuup.admin.modules.contacts.views.reset
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.admin.modules.contacts.views
    :members:
    :undoc-members:
    :show-inheritance:
