shuup.notify.conditions package
===============================

Submodules
----------

shuup.notify.conditions.simple module
-------------------------------------

.. automodule:: shuup.notify.conditions.simple
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.notify.conditions
    :members:
    :undoc-members:
    :show-inheritance:
