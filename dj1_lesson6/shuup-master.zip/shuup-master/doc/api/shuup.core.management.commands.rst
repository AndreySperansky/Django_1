shuup.core.management.commands package
======================================

Submodules
----------

shuup.core.management.commands.compute\_bought\_with\_relations module
----------------------------------------------------------------------

.. automodule:: shuup.core.management.commands.compute_bought_with_relations
    :members:
    :undoc-members:
    :show-inheritance:

shuup.core.management.commands.makemessages module
--------------------------------------------------

.. automodule:: shuup.core.management.commands.makemessages
    :members:
    :undoc-members:
    :show-inheritance:

shuup.core.management.commands.shuup\_extract\_products\_shortdescription module
--------------------------------------------------------------------------------

.. automodule:: shuup.core.management.commands.shuup_extract_products_shortdescription
    :members:
    :undoc-members:
    :show-inheritance:

shuup.core.management.commands.shuup\_fix\_order\_status\_identifiers module
----------------------------------------------------------------------------

.. automodule:: shuup.core.management.commands.shuup_fix_order_status_identifiers
    :members:
    :undoc-members:
    :show-inheritance:

shuup.core.management.commands.shuup\_init module
-------------------------------------------------

.. automodule:: shuup.core.management.commands.shuup_init
    :members:
    :undoc-members:
    :show-inheritance:

shuup.core.management.commands.shuup\_makemessages module
---------------------------------------------------------

.. automodule:: shuup.core.management.commands.shuup_makemessages
    :members:
    :undoc-members:
    :show-inheritance:

shuup.core.management.commands.shuup\_migrate\_from\_shoop module
-----------------------------------------------------------------

.. automodule:: shuup.core.management.commands.shuup_migrate_from_shoop
    :members:
    :undoc-members:
    :show-inheritance:

shuup.core.management.commands.shuup\_show\_settings module
-----------------------------------------------------------

.. automodule:: shuup.core.management.commands.shuup_show_settings
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.core.management.commands
    :members:
    :undoc-members:
    :show-inheritance:
