shuup.testing.modules.sample\_data package
==========================================

Submodules
----------

shuup.testing.modules.sample\_data.data module
----------------------------------------------

.. automodule:: shuup.testing.modules.sample_data.data
    :members:
    :undoc-members:
    :show-inheritance:

shuup.testing.modules.sample\_data.factories module
---------------------------------------------------

.. automodule:: shuup.testing.modules.sample_data.factories
    :members:
    :undoc-members:
    :show-inheritance:

shuup.testing.modules.sample\_data.forms module
-----------------------------------------------

.. automodule:: shuup.testing.modules.sample_data.forms
    :members:
    :undoc-members:
    :show-inheritance:

shuup.testing.modules.sample\_data.manager module
-------------------------------------------------

.. automodule:: shuup.testing.modules.sample_data.manager
    :members:
    :undoc-members:
    :show-inheritance:

shuup.testing.modules.sample\_data.views module
-----------------------------------------------

.. automodule:: shuup.testing.modules.sample_data.views
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.testing.modules.sample_data
    :members:
    :undoc-members:
    :show-inheritance:
