shuup.front.apps.recently\_viewed\_products package
===================================================

Submodules
----------

shuup.front.apps.recently\_viewed\_products.plugins module
----------------------------------------------------------

.. automodule:: shuup.front.apps.recently_viewed_products.plugins
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.front.apps.recently_viewed_products
    :members:
    :undoc-members:
    :show-inheritance:
