shuup.front.notify\_script\_templates package
=============================================

Submodules
----------

shuup.front.notify\_script\_templates.generics module
-----------------------------------------------------

.. automodule:: shuup.front.notify_script_templates.generics
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.front.notify_script_templates
    :members:
    :undoc-members:
    :show-inheritance:
