shuup.notify.models package
===========================

Submodules
----------

shuup.notify.models.notification module
---------------------------------------

.. automodule:: shuup.notify.models.notification
    :members:
    :undoc-members:
    :show-inheritance:

shuup.notify.models.script module
---------------------------------

.. automodule:: shuup.notify.models.script
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.notify.models
    :members:
    :undoc-members:
    :show-inheritance:
