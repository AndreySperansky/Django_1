shuup.admin.modules.permission\_groups.views package
====================================================

Submodules
----------

shuup.admin.modules.permission\_groups.views.edit module
--------------------------------------------------------

.. automodule:: shuup.admin.modules.permission_groups.views.edit
    :members:
    :undoc-members:
    :show-inheritance:

shuup.admin.modules.permission\_groups.views.list module
--------------------------------------------------------

.. automodule:: shuup.admin.modules.permission_groups.views.list
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.admin.modules.permission_groups.views
    :members:
    :undoc-members:
    :show-inheritance:
