shuup.admin.modules.sales\_dashboard package
============================================

Submodules
----------

shuup.admin.modules.sales\_dashboard.dashboard module
-----------------------------------------------------

.. automodule:: shuup.admin.modules.sales_dashboard.dashboard
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.admin.modules.sales_dashboard
    :members:
    :undoc-members:
    :show-inheritance:
