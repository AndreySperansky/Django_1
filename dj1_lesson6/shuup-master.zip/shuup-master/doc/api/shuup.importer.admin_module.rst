shuup.importer.admin\_module package
====================================

Submodules
----------

shuup.importer.admin\_module.forms module
-----------------------------------------

.. automodule:: shuup.importer.admin_module.forms
    :members:
    :undoc-members:
    :show-inheritance:

shuup.importer.admin\_module.import\_views module
-------------------------------------------------

.. automodule:: shuup.importer.admin_module.import_views
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.importer.admin_module
    :members:
    :undoc-members:
    :show-inheritance:
