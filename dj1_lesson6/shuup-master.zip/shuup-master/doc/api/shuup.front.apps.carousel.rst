shuup.front.apps.carousel package
=================================

Subpackages
-----------

.. toctree::

    shuup.front.apps.carousel.admin_module

Submodules
----------

shuup.front.apps.carousel.apps module
-------------------------------------

.. automodule:: shuup.front.apps.carousel.apps
    :members:
    :undoc-members:
    :show-inheritance:

shuup.front.apps.carousel.forms module
--------------------------------------

.. automodule:: shuup.front.apps.carousel.forms
    :members:
    :undoc-members:
    :show-inheritance:

shuup.front.apps.carousel.models module
---------------------------------------

.. automodule:: shuup.front.apps.carousel.models
    :members:
    :undoc-members:
    :show-inheritance:

shuup.front.apps.carousel.plugins module
----------------------------------------

.. automodule:: shuup.front.apps.carousel.plugins
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.front.apps.carousel
    :members:
    :undoc-members:
    :show-inheritance:
