shuup.admin.templatetags package
================================

Submodules
----------

shuup.admin.templatetags.shuup\_admin module
--------------------------------------------

.. automodule:: shuup.admin.templatetags.shuup_admin
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.admin.templatetags
    :members:
    :undoc-members:
    :show-inheritance:
