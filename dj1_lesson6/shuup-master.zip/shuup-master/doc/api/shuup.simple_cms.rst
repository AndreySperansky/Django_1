shuup.simple\_cms package
=========================

Subpackages
-----------

.. toctree::

    shuup.simple_cms.admin_module

Submodules
----------

shuup.simple\_cms.layout module
-------------------------------

.. automodule:: shuup.simple_cms.layout
    :members:
    :undoc-members:
    :show-inheritance:

shuup.simple\_cms.models module
-------------------------------

.. automodule:: shuup.simple_cms.models
    :members:
    :undoc-members:
    :show-inheritance:

shuup.simple\_cms.plugins module
--------------------------------

.. automodule:: shuup.simple_cms.plugins
    :members:
    :undoc-members:
    :show-inheritance:

shuup.simple\_cms.settings module
---------------------------------

.. automodule:: shuup.simple_cms.settings
    :members:
    :undoc-members:
    :show-inheritance:

shuup.simple\_cms.template\_helpers module
------------------------------------------

.. automodule:: shuup.simple_cms.template_helpers
    :members:
    :undoc-members:
    :show-inheritance:

shuup.simple\_cms.templates module
----------------------------------

.. automodule:: shuup.simple_cms.templates
    :members:
    :undoc-members:
    :show-inheritance:

shuup.simple\_cms.urls module
-----------------------------

.. automodule:: shuup.simple_cms.urls
    :members:
    :undoc-members:
    :show-inheritance:

shuup.simple\_cms.views module
------------------------------

.. automodule:: shuup.simple_cms.views
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.simple_cms
    :members:
    :undoc-members:
    :show-inheritance:
