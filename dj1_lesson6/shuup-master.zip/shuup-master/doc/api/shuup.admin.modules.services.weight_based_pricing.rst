shuup.admin.modules.services.weight\_based\_pricing package
===========================================================

Module contents
---------------

.. automodule:: shuup.admin.modules.services.weight_based_pricing
    :members:
    :undoc-members:
    :show-inheritance:
