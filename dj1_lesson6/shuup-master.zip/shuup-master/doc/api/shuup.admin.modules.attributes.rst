shuup.admin.modules.attributes package
======================================

Subpackages
-----------

.. toctree::

    shuup.admin.modules.attributes.views

Module contents
---------------

.. automodule:: shuup.admin.modules.attributes
    :members:
    :undoc-members:
    :show-inheritance:
