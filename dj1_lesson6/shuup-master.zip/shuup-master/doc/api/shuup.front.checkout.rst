shuup.front.checkout package
============================

Submodules
----------

shuup.front.checkout.addresses module
-------------------------------------

.. automodule:: shuup.front.checkout.addresses
    :members:
    :undoc-members:
    :show-inheritance:

shuup.front.checkout.checkout\_method module
--------------------------------------------

.. automodule:: shuup.front.checkout.checkout_method
    :members:
    :undoc-members:
    :show-inheritance:

shuup.front.checkout.confirm module
-----------------------------------

.. automodule:: shuup.front.checkout.confirm
    :members:
    :undoc-members:
    :show-inheritance:

shuup.front.checkout.empty module
---------------------------------

.. automodule:: shuup.front.checkout.empty
    :members:
    :undoc-members:
    :show-inheritance:

shuup.front.checkout.methods module
-----------------------------------

.. automodule:: shuup.front.checkout.methods
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.front.checkout
    :members:
    :undoc-members:
    :show-inheritance:
