shuup.testing.modules.mocker package
====================================

Submodules
----------

shuup.testing.modules.mocker.mass\_actions module
-------------------------------------------------

.. automodule:: shuup.testing.modules.mocker.mass_actions
    :members:
    :undoc-members:
    :show-inheritance:

shuup.testing.modules.mocker.mocker\_view module
------------------------------------------------

.. automodule:: shuup.testing.modules.mocker.mocker_view
    :members:
    :undoc-members:
    :show-inheritance:

shuup.testing.modules.mocker.sections module
--------------------------------------------

.. automodule:: shuup.testing.modules.mocker.sections
    :members:
    :undoc-members:
    :show-inheritance:

shuup.testing.modules.mocker.toolbar module
-------------------------------------------

.. automodule:: shuup.testing.modules.mocker.toolbar
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.testing.modules.mocker
    :members:
    :undoc-members:
    :show-inheritance:
