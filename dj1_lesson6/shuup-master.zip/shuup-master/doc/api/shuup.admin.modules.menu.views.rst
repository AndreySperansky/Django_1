shuup.admin.modules.menu.views package
======================================

Submodules
----------

shuup.admin.modules.menu.views.arrange module
---------------------------------------------

.. automodule:: shuup.admin.modules.menu.views.arrange
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.admin.modules.menu.views
    :members:
    :undoc-members:
    :show-inheritance:
