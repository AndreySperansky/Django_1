shuup.front.apps.simple\_order\_notification package
====================================================

Subpackages
-----------

.. toctree::

    shuup.front.apps.simple_order_notification.admin_module

Submodules
----------

shuup.front.apps.simple\_order\_notification.signal\_handler module
-------------------------------------------------------------------

.. automodule:: shuup.front.apps.simple_order_notification.signal_handler
    :members:
    :undoc-members:
    :show-inheritance:

shuup.front.apps.simple\_order\_notification.templates module
-------------------------------------------------------------

.. automodule:: shuup.front.apps.simple_order_notification.templates
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.front.apps.simple_order_notification
    :members:
    :undoc-members:
    :show-inheritance:
