shuup.front.admin\_module.translation package
=============================================

Submodules
----------

shuup.front.admin\_module.translation.form\_parts module
--------------------------------------------------------

.. automodule:: shuup.front.admin_module.translation.form_parts
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.front.admin_module.translation
    :members:
    :undoc-members:
    :show-inheritance:
