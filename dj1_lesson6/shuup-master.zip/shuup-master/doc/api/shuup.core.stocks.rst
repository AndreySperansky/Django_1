shuup.core.stocks package
=========================

Module contents
---------------

.. automodule:: shuup.core.stocks
    :members:
    :undoc-members:
    :show-inheritance:
