shuup package
=============

Subpackages
-----------

.. toctree::

    shuup.addons
    shuup.admin
    shuup.apps
    shuup.campaigns
    shuup.core
    shuup.customer_group_pricing
    shuup.default_importer
    shuup.default_reports
    shuup.default_tax
    shuup.discounts
    shuup.front
    shuup.gdpr
    shuup.guide
    shuup.importer
    shuup.notify
    shuup.order_printouts
    shuup.regions
    shuup.reports
    shuup.simple_cms
    shuup.simple_supplier
    shuup.tasks
    shuup.testing
    shuup.themes
    shuup.utils
    shuup.xtheme

Submodules
----------

shuup.configuration module
--------------------------

.. automodule:: shuup.configuration
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup
    :members:
    :undoc-members:
    :show-inheritance:
