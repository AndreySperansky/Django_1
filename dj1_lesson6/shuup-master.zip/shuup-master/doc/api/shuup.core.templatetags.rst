shuup.core.templatetags package
===============================

Submodules
----------

shuup.core.templatetags.prices module
-------------------------------------

.. automodule:: shuup.core.templatetags.prices
    :members:
    :undoc-members:
    :show-inheritance:

shuup.core.templatetags.shuup\_common module
--------------------------------------------

.. automodule:: shuup.core.templatetags.shuup_common
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.core.templatetags
    :members:
    :undoc-members:
    :show-inheritance:
