shuup.core.defaults package
===========================

Submodules
----------

shuup.core.defaults.order\_statuses module
------------------------------------------

.. automodule:: shuup.core.defaults.order_statuses
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.core.defaults
    :members:
    :undoc-members:
    :show-inheritance:
