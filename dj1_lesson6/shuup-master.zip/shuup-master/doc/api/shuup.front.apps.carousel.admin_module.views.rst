shuup.front.apps.carousel.admin\_module.views package
=====================================================

Module contents
---------------

.. automodule:: shuup.front.apps.carousel.admin_module.views
    :members:
    :undoc-members:
    :show-inheritance:
