shuup.admin.modules.service\_providers package
==============================================

Subpackages
-----------

.. toctree::

    shuup.admin.modules.service_providers.views

Submodules
----------

shuup.admin.modules.service\_providers.forms module
---------------------------------------------------

.. automodule:: shuup.admin.modules.service_providers.forms
    :members:
    :undoc-members:
    :show-inheritance:

shuup.admin.modules.service\_providers.wizard\_form\_defs module
----------------------------------------------------------------

.. automodule:: shuup.admin.modules.service_providers.wizard_form_defs
    :members:
    :undoc-members:
    :show-inheritance:

shuup.admin.modules.service\_providers.wizard\_forms module
-----------------------------------------------------------

.. automodule:: shuup.admin.modules.service_providers.wizard_forms
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.admin.modules.service_providers
    :members:
    :undoc-members:
    :show-inheritance:
