shuup.front.apps.simple\_order\_notification.admin\_module package
==================================================================

Module contents
---------------

.. automodule:: shuup.front.apps.simple_order_notification.admin_module
    :members:
    :undoc-members:
    :show-inheritance:
